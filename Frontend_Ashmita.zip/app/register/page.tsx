"use client"

import { useState } from "react"
import { GlassCard } from "@/components/glass-card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Field, FieldGroup, FieldLabel } from "@/components/ui/field"
import { Package, MapPin, Calendar, CheckCircle2, Hash, Copy, Check, Sparkles } from "lucide-react"

// Generate a realistic looking hash
function generateHash(): string {
  const chars = "0123456789abcdef"
  let hash = "0x"
  for (let i = 0; i < 64; i++) {
    hash += chars[Math.floor(Math.random() * chars.length)]
  }
  return hash
}

export default function RegisterPage() {
  const [submitted, setSubmitted] = useState(false)
  const [copied, setCopied] = useState(false)
  const [generatedHash, setGeneratedHash] = useState("")
  const [formData, setFormData] = useState({
    productName: "",
    expiryDate: "",
    origin: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const hash = generateHash()
    setGeneratedHash(hash)
    setSubmitted(true)
  }

  const copyHash = () => {
    navigator.clipboard.writeText(generatedHash)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleRegisterAnother = () => {
    setSubmitted(false)
    setGeneratedHash("")
    setFormData({ productName: "", expiryDate: "", origin: "" })
  }

  if (submitted) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="relative">
          {/* Floating glow effect behind the card */}
          <div className="absolute inset-0 -z-10">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-64 w-64 rounded-full bg-valid/30 blur-[100px]" />
          </div>
          
          <GlassCard glow="valid" className="text-center relative overflow-hidden">
            {/* Subtle gradient overlay */}
            <div className="absolute inset-0 bg-gradient-to-br from-valid/5 via-transparent to-primary/5" />
            
            <div className="relative">
              {/* Success icon with glow */}
              <div className="mb-6 inline-flex h-24 w-24 items-center justify-center rounded-full bg-gradient-to-br from-valid/20 to-valid/10 shadow-lg shadow-valid/30">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-valid/20">
                  <CheckCircle2 className="h-10 w-10 text-valid" />
                </div>
              </div>
              
              <h2 className="mb-2 text-2xl font-bold text-foreground">Product Registered Successfully</h2>
              <p className="text-muted-foreground mb-6">
                Your product has been added to the Truenza supply chain system.
              </p>
              
              {/* Product Summary */}
              <div className="mb-6 rounded-xl border border-border/50 bg-secondary/30 p-4 text-left">
                <div className="grid gap-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Product Name</span>
                    <span className="font-medium text-foreground">{formData.productName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Expiry Date</span>
                    <span className="font-medium text-foreground">{formData.expiryDate}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Origin</span>
                    <span className="font-medium text-foreground">{formData.origin}</span>
                  </div>
                </div>
              </div>
              
              {/* Generated Hash Card */}
              <div className="rounded-xl border border-primary/30 bg-gradient-to-br from-primary/10 via-primary/5 to-accent/10 p-5">
                <div className="mb-3 flex items-center justify-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/20">
                    <Hash className="h-4 w-4 text-primary" />
                  </div>
                  <span className="font-semibold text-foreground">Product Hash</span>
                </div>
                
                <div className="relative group">
                  <div className="rounded-lg border border-border/50 bg-background/50 p-3 font-mono text-xs break-all text-muted-foreground">
                    {generatedHash}
                  </div>
                  <button
                    onClick={copyHash}
                    className="absolute right-2 top-1/2 -translate-y-1/2 flex h-8 w-8 items-center justify-center rounded-md bg-primary/20 text-primary opacity-0 transition-opacity group-hover:opacity-100 hover:bg-primary/30"
                    title="Copy hash"
                  >
                    {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                  </button>
                </div>
                
                {copied && (
                  <p className="mt-2 text-xs text-valid font-medium">Hash copied to clipboard</p>
                )}
              </div>
              
              {/* Action Buttons */}
              <div className="mt-6 flex flex-col sm:flex-row gap-3 justify-center">
                <Button 
                  onClick={handleRegisterAnother}
                  className="rounded-xl bg-gradient-to-r from-primary to-accent text-primary-foreground font-semibold shadow-lg shadow-primary/40 hover:shadow-xl hover:shadow-primary/50 hover:scale-105 transition-all"
                >
                  <Sparkles className="mr-2 h-4 w-4" />
                  Register Another Product
                </Button>
              </div>
            </div>
          </GlassCard>
        </div>
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-xl px-4 py-12 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="mb-8 text-center relative">
        {/* Glow behind header */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 h-32 w-48 bg-primary/20 blur-[80px] -z-10" />
        
        <div className="mb-4 inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-accent shadow-lg shadow-primary/40">
          <Package className="h-8 w-8 text-primary-foreground" />
        </div>
        <h1 className="mb-2 text-3xl font-bold text-foreground">Register Product</h1>
        <p className="text-muted-foreground">
          Add a new product to the Truenza supply chain
        </p>
      </div>

      {/* Form Card */}
      <div className="relative">
        {/* Floating glow effect */}
        <div className="absolute -inset-4 -z-10">
          <div className="absolute top-1/4 -left-8 h-32 w-32 rounded-full bg-primary/15 blur-[60px]" />
          <div className="absolute bottom-1/4 -right-8 h-32 w-32 rounded-full bg-accent/15 blur-[60px]" />
        </div>
        
        <GlassCard className="relative overflow-hidden">
          {/* Subtle gradient border glow */}
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />
          
          <form onSubmit={handleSubmit} className="relative">
            <FieldGroup>
              {/* Product Name */}
              <Field>
                <FieldLabel className="text-foreground font-medium">Product Name</FieldLabel>
                <div className="relative group">
                  <Package className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground transition-colors group-focus-within:text-primary" />
                  <Input
                    placeholder="Enter product name"
                    className="h-12 pl-12 rounded-xl border-border/50 bg-secondary/30 backdrop-blur-sm transition-all focus:border-primary/50 focus:bg-secondary/50 focus:ring-2 focus:ring-primary/20"
                    value={formData.productName}
                    onChange={(e) => setFormData({ ...formData, productName: e.target.value })}
                    required
                  />
                </div>
              </Field>

              {/* Expiry Date */}
              <Field>
                <FieldLabel className="text-foreground font-medium">Expiry Date</FieldLabel>
                <div className="relative group">
                  <Calendar className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground transition-colors group-focus-within:text-primary" />
                  <Input
                    type="date"
                    className="h-12 pl-12 rounded-xl border-border/50 bg-secondary/30 backdrop-blur-sm transition-all focus:border-primary/50 focus:bg-secondary/50 focus:ring-2 focus:ring-primary/20"
                    value={formData.expiryDate}
                    onChange={(e) => setFormData({ ...formData, expiryDate: e.target.value })}
                    required
                  />
                </div>
              </Field>

              {/* Origin */}
              <Field>
                <FieldLabel className="text-foreground font-medium">Origin</FieldLabel>
                <div className="relative group">
                  <MapPin className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground transition-colors group-focus-within:text-primary" />
                  <Input
                    placeholder="City, Country"
                    className="h-12 pl-12 rounded-xl border-border/50 bg-secondary/30 backdrop-blur-sm transition-all focus:border-primary/50 focus:bg-secondary/50 focus:ring-2 focus:ring-primary/20"
                    value={formData.origin}
                    onChange={(e) => setFormData({ ...formData, origin: e.target.value })}
                    required
                  />
                </div>
              </Field>
            </FieldGroup>

            {/* Submit Button */}
            <div className="mt-8">
              <Button 
                type="submit" 
                className="w-full h-12 rounded-xl bg-gradient-to-r from-primary to-accent text-primary-foreground font-semibold text-base shadow-lg shadow-primary/40 hover:shadow-xl hover:shadow-primary/50 hover:scale-[1.02] transition-all"
              >
                <Sparkles className="mr-2 h-5 w-5" />
                Register Product
              </Button>
            </div>
          </form>
        </GlassCard>
      </div>
    </div>
  )
}
