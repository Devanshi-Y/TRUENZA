"use client"

import { useState } from "react"
import { GlassCard } from "@/components/glass-card"
import { Button } from "@/components/ui/button"
import { ScanLine, Camera, ShieldCheck, ShieldAlert, Package, MapPin, Calendar, Building2, Truck, CheckCircle2, XCircle, Scan } from "lucide-react"

type ScanStatus = "idle" | "scanning" | "valid" | "tampered"

interface ProductDetails {
  id: string
  name: string
  origin: string
  manufacturer: string
  productionDate: string
  supplyChain: {
    step: string
    location: string
    date: string
    verified: boolean
  }[]
}

const mockValidProduct: ProductDetails = {
  id: "TRZ-A8F3K2M1",
  name: "Organic Valley Milk",
  origin: "Wisconsin, USA",
  manufacturer: "Organic Valley Co.",
  productionDate: "2024-03-15",
  supplyChain: [
    { step: "Production", location: "Wisconsin, USA", date: "Mar 15, 2024", verified: true },
    { step: "Quality Check", location: "Madison, WI", date: "Mar 16, 2024", verified: true },
    { step: "Distribution", location: "Chicago, IL", date: "Mar 17, 2024", verified: true },
    { step: "Retail", location: "Store #1247", date: "Mar 18, 2024", verified: true },
  ],
}

const mockTamperedProduct: ProductDetails = {
  id: "TRZ-X9Z2Y7P4",
  name: "Premium Salmon Fillet",
  origin: "Unknown",
  manufacturer: "Unverified Source",
  productionDate: "N/A",
  supplyChain: [
    { step: "Production", location: "Unknown", date: "Unknown", verified: false },
    { step: "Quality Check", location: "Missing", date: "N/A", verified: false },
    { step: "Distribution", location: "Unverified", date: "N/A", verified: false },
  ],
}

export default function ScanPage() {
  const [status, setStatus] = useState<ScanStatus>("idle")
  const [product, setProduct] = useState<ProductDetails | null>(null)

  const handleScan = () => {
    setStatus("scanning")
    
    // Simulate scanning delay
    setTimeout(() => {
      // Random result for demo
      const isValid = Math.random() > 0.3
      if (isValid) {
        setStatus("valid")
        setProduct(mockValidProduct)
      } else {
        setStatus("tampered")
        setProduct(mockTamperedProduct)
      }
    }, 2000)
  }

  const resetScan = () => {
    setStatus("idle")
    setProduct(null)
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8">
      {/* Idle / Scanner State */}
      {(status === "idle" || status === "scanning") && (
        <div className="flex flex-col items-center">
          {/* Header */}
          <div className="mb-8 text-center">
            <div className="mb-4 inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-accent shadow-lg shadow-primary/40">
              <ScanLine className="h-8 w-8 text-primary-foreground" />
            </div>
            <h1 className="mb-2 text-3xl font-bold text-foreground">Scan Product</h1>
            <p className="text-muted-foreground">
              Point your camera at the QR code to verify product authenticity
            </p>
          </div>

          {/* Scanner Card */}
          <GlassCard className="w-full max-w-md relative overflow-hidden">
            {/* Background glow effect */}
            <div className="absolute -top-20 -left-20 h-40 w-40 rounded-full bg-primary/20 blur-[80px]" />
            <div className="absolute -bottom-20 -right-20 h-40 w-40 rounded-full bg-accent/20 blur-[80px]" />
            
            <div className="relative">
              {/* Scanner Box */}
              <div className="relative mx-auto aspect-square w-full max-w-[280px] overflow-hidden rounded-2xl">
                {/* Outer glow ring */}
                <div className={`absolute inset-0 rounded-2xl ${status === "scanning" ? "animate-pulse" : ""}`}>
                  <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-primary/30 via-accent/20 to-primary/30" />
                  <div className="absolute inset-[2px] rounded-2xl bg-background/90" />
                </div>
                
                {/* Scanner area */}
                <div className="absolute inset-[3px] rounded-xl bg-gradient-to-br from-secondary/80 to-muted/50 backdrop-blur-sm">
                  {/* Corner markers */}
                  <div className="absolute left-3 top-3 h-8 w-8 border-l-2 border-t-2 border-primary rounded-tl-lg" />
                  <div className="absolute right-3 top-3 h-8 w-8 border-r-2 border-t-2 border-primary rounded-tr-lg" />
                  <div className="absolute bottom-3 left-3 h-8 w-8 border-b-2 border-l-2 border-primary rounded-bl-lg" />
                  <div className="absolute bottom-3 right-3 h-8 w-8 border-b-2 border-r-2 border-primary rounded-br-lg" />
                  
                  {/* Center content */}
                  <div className="flex h-full flex-col items-center justify-center px-6">
                    {status === "scanning" ? (
                      <>
                        {/* Scanning animation */}
                        <div className="relative mb-4">
                          <div className="h-16 w-16 rounded-full border-4 border-primary/30" />
                          <div className="absolute inset-0 h-16 w-16 animate-spin rounded-full border-4 border-transparent border-t-primary" />
                          <Scan className="absolute left-1/2 top-1/2 h-6 w-6 -translate-x-1/2 -translate-y-1/2 text-primary" />
                        </div>
                        <p className="text-sm font-medium text-foreground">Scanning...</p>
                        <p className="mt-1 text-xs text-muted-foreground">Analyzing QR code</p>
                        
                        {/* Scan line animation */}
                        <div className="absolute inset-x-6 top-1/4 h-0.5 animate-[scan_2s_ease-in-out_infinite] bg-gradient-to-r from-transparent via-primary to-transparent opacity-75" />
                      </>
                    ) : (
                      <>
                        {/* Camera placeholder */}
                        <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                          <Camera className="h-8 w-8 text-primary/70" />
                        </div>
                        <p className="text-sm font-medium text-foreground">Camera Preview</p>
                        <p className="mt-1 text-center text-xs text-muted-foreground">
                          Position QR code within the frame
                        </p>
                      </>
                    )}
                  </div>
                </div>
              </div>

              {/* Instructions */}
              <div className="mt-6 space-y-3">
                <div className="flex items-center gap-3 text-sm text-muted-foreground">
                  <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary">1</div>
                  <span>Locate the QR code on the product packaging</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-muted-foreground">
                  <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary">2</div>
                  <span>Align the code within the scanner frame</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-muted-foreground">
                  <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary">3</div>
                  <span>Hold steady for automatic verification</span>
                </div>
              </div>

              {/* Scan Button */}
              <Button 
                onClick={handleScan}
                disabled={status === "scanning"}
                className="mt-6 w-full rounded-xl bg-gradient-to-r from-primary to-accent text-primary-foreground font-semibold shadow-lg shadow-primary/40 hover:shadow-xl hover:shadow-primary/50 hover:scale-[1.02] transition-all"
                size="lg"
              >
                {status === "scanning" ? (
                  <>
                    <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
                    Verifying Product...
                  </>
                ) : (
                  <>
                    <Scan className="mr-2 h-5 w-5" />
                    Start Scanning
                  </>
                )}
              </Button>
            </div>
          </GlassCard>

          {/* Info text */}
          <p className="mt-6 max-w-md text-center text-xs text-muted-foreground">
            Truenza uses advanced verification to ensure your products are authentic and safely sourced through the entire supply chain.
          </p>
        </div>
      )}

      {/* Valid Result */}
      {status === "valid" && product && (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
          {/* Status Card */}
          <GlassCard glow="valid" className="text-center relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-valid/10 to-transparent" />
            <div className="absolute -top-20 left-1/2 -translate-x-1/2 h-40 w-40 rounded-full bg-valid/20 blur-[80px]" />
            <div className="relative">
              <div className="mb-4 inline-flex h-20 w-20 items-center justify-center rounded-full bg-valid/20 shadow-lg shadow-valid/30">
                <ShieldCheck className="h-10 w-10 text-valid" />
              </div>
              <h2 className="mb-2 text-2xl font-bold text-valid">Product Verified</h2>
              <p className="text-muted-foreground">
                This product has been authenticated and all supply chain checkpoints are verified.
              </p>
            </div>
          </GlassCard>

          {/* Product Details */}
          <GlassCard>
            <h3 className="mb-6 flex items-center gap-2 text-lg font-semibold text-foreground">
              <Package className="h-5 w-5 text-primary" />
              Product Details
            </h3>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10">
                  <Package className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Product Name</p>
                  <p className="font-medium text-foreground">{product.name}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10">
                  <MapPin className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Origin</p>
                  <p className="font-medium text-foreground">{product.origin}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10">
                  <Building2 className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Manufacturer</p>
                  <p className="font-medium text-foreground">{product.manufacturer}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10">
                  <Calendar className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Production Date</p>
                  <p className="font-medium text-foreground">{product.productionDate}</p>
                </div>
              </div>
            </div>
          </GlassCard>

          {/* Supply Chain */}
          <GlassCard>
            <h3 className="mb-6 flex items-center gap-2 text-lg font-semibold text-foreground">
              <Truck className="h-5 w-5 text-primary" />
              Supply Chain Journey
            </h3>
            <div className="space-y-4">
              {product.supplyChain.map((step, index) => (
                <div key={index} className="flex items-center gap-4">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-valid/10">
                    <CheckCircle2 className="h-5 w-5 text-valid" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <p className="font-medium text-foreground">{step.step}</p>
                      <span className="text-sm text-muted-foreground">{step.date}</span>
                    </div>
                    <p className="text-sm text-muted-foreground">{step.location}</p>
                  </div>
                </div>
              ))}
            </div>
          </GlassCard>

          <div className="text-center">
            <Button onClick={resetScan} variant="outline" className="rounded-xl border-border hover:bg-card/80">
              Scan Another Product
            </Button>
          </div>
        </div>
      )}

      {/* Tampered Result */}
      {status === "tampered" && product && (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
          {/* Status Card */}
          <GlassCard glow="tampered" className="text-center relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-tampered/10 to-transparent" />
            <div className="absolute -top-20 left-1/2 -translate-x-1/2 h-40 w-40 rounded-full bg-tampered/20 blur-[80px]" />
            <div className="relative">
              <div className="mb-4 inline-flex h-20 w-20 items-center justify-center rounded-full bg-tampered/20 shadow-lg shadow-tampered/30">
                <ShieldAlert className="h-10 w-10 text-tampered" />
              </div>
              <h2 className="mb-2 text-2xl font-bold text-tampered">Verification Failed</h2>
              <p className="text-muted-foreground">
                This product could not be verified. Supply chain integrity may be compromised.
              </p>
            </div>
          </GlassCard>

          {/* Warning Details */}
          <GlassCard className="border-tampered/20">
            <h3 className="mb-6 flex items-center gap-2 text-lg font-semibold text-foreground">
              <ShieldAlert className="h-5 w-5 text-tampered" />
              Warning Details
            </h3>
            <div className="space-y-4">
              {product.supplyChain.map((step, index) => (
                <div key={index} className="flex items-center gap-4">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-tampered/10">
                    <XCircle className="h-5 w-5 text-tampered" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <p className="font-medium text-foreground">{step.step}</p>
                      <span className="rounded-full bg-tampered/10 px-2 py-0.5 text-xs font-medium text-tampered">
                        Unverified
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">{step.location}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-6 rounded-xl bg-tampered/5 border border-tampered/20 p-4">
              <p className="text-sm text-tampered">
                <strong>Recommendation:</strong> Do not consume this product. Report this incident to authorities 
                and contact the retailer immediately.
              </p>
            </div>
          </GlassCard>

          <div className="text-center">
            <Button onClick={resetScan} variant="outline" className="rounded-xl border-border hover:bg-card/80">
              Scan Another Product
            </Button>
          </div>
        </div>
      )}

      {/* Custom scan animation keyframe */}
      <style jsx>{`
        @keyframes scan {
          0%, 100% { top: 25%; opacity: 0.5; }
          50% { top: 75%; opacity: 1; }
        }
      `}</style>
    </div>
  )
}
