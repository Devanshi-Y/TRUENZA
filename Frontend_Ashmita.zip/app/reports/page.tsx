"use client"

import { GlassCard } from "@/components/glass-card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { FileBarChart, TrendingUp, Package, ShieldCheck, ShieldAlert, Download, ArrowUpRight, ArrowDownRight } from "lucide-react"
import { useState } from "react"

const overviewStats = [
  { label: "Total Products", value: "12,847", change: "+12%", trend: "up", icon: Package },
  { label: "Verified Products", value: "12,584", change: "+8%", trend: "up", icon: ShieldCheck },
  { label: "Flagged Products", value: "263", change: "-15%", trend: "down", icon: ShieldAlert },
  { label: "Integrity Score", value: "97.9%", change: "+2.3%", trend: "up", icon: TrendingUp },
]

const recentActivities = [
  { id: "TRZ-A8F3K2M1", product: "Organic Valley Milk", status: "verified", time: "2 min ago" },
  { id: "TRZ-B2C9D4E5", product: "Fresh Atlantic Salmon", status: "verified", time: "5 min ago" },
  { id: "TRZ-X9Z2Y7P4", product: "Premium Beef Steak", status: "flagged", time: "12 min ago" },
  { id: "TRZ-F6G8H1J3", product: "Organic Spinach", status: "verified", time: "18 min ago" },
  { id: "TRZ-K4L7M0N2", product: "Free Range Eggs", status: "verified", time: "25 min ago" },
  { id: "TRZ-P3Q5R8S1", product: "Imported Olive Oil", status: "flagged", time: "32 min ago" },
]

const categoryData = [
  { name: "Fresh Produce", products: 3420, verified: 98.5 },
  { name: "Dairy Products", products: 2845, verified: 99.1 },
  { name: "Meat & Poultry", products: 2180, verified: 96.8 },
  { name: "Seafood", products: 1650, verified: 94.2 },
  { name: "Grains & Cereals", products: 1420, verified: 99.4 },
  { name: "Beverages", products: 1332, verified: 98.9 },
]

export default function ReportsPage() {
  const [timeRange, setTimeRange] = useState("7d")

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="flex items-center gap-3 text-3xl font-bold text-foreground">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-accent shadow-lg shadow-primary/40">
              <FileBarChart className="h-6 w-6 text-primary-foreground" />
            </div>
            Reports & Analytics
          </h1>
          <p className="mt-2 text-muted-foreground">
            Supply chain integrity metrics and verification analytics
          </p>
        </div>
        <div className="flex gap-3">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[140px] rounded-xl">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="24h">Last 24 hours</SelectItem>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" className="rounded-xl">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      {/* Overview Stats */}
      <div className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {overviewStats.map((stat) => {
          const Icon = stat.icon
          const TrendIcon = stat.trend === "up" ? ArrowUpRight : ArrowDownRight
          const isPositive = stat.trend === "up"
          return (
            <GlassCard key={stat.label} className="group hover:-translate-y-1">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                  <p className="mt-1 text-3xl font-bold text-foreground">{stat.value}</p>
                  <div className={`mt-2 flex items-center gap-1 text-sm font-semibold ${isPositive ? "text-valid" : "text-tampered"}`}>
                    <TrendIcon className="h-4 w-4" />
                    <span>{stat.change}</span>
                  </div>
                </div>
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 group-hover:from-primary/30 group-hover:to-accent/30 transition-colors">
                  <Icon className="h-6 w-6 text-primary" />
                </div>
              </div>
            </GlassCard>
          )
        })}
      </div>

      <div className="grid gap-8 lg:grid-cols-2">
        {/* Category Breakdown */}
        <GlassCard>
          <h3 className="mb-6 text-lg font-semibold text-foreground">Category Breakdown</h3>
          <div className="space-y-4">
            {categoryData.map((category) => (
              <div key={category.name}>
                <div className="mb-2 flex items-center justify-between">
                  <span className="text-sm font-medium text-foreground">{category.name}</span>
                  <span className="text-sm text-muted-foreground">{category.products.toLocaleString()} products</span>
                </div>
                <div className="relative h-2 overflow-hidden rounded-full bg-secondary">
                  <div
                    className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-primary to-accent"
                    style={{ width: `${category.verified}%` }}
                  />
                </div>
                <p className="mt-1 text-xs text-muted-foreground">{category.verified}% verified</p>
              </div>
            ))}
          </div>
        </GlassCard>

        {/* Recent Activity */}
        <GlassCard>
          <h3 className="mb-6 text-lg font-semibold text-foreground">Recent Activity</h3>
          <div className="space-y-4">
            {recentActivities.map((activity) => (
              <div key={activity.id} className="flex items-center gap-4">
                <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full ${
                  activity.status === "verified" ? "bg-valid/10" : "bg-tampered/10"
                }`}>
                  {activity.status === "verified" ? (
                    <ShieldCheck className="h-5 w-5 text-valid" />
                  ) : (
                    <ShieldAlert className="h-5 w-5 text-tampered" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="truncate font-medium text-foreground">{activity.product}</p>
                  <p className="text-sm text-muted-foreground">{activity.id}</p>
                </div>
                <div className="text-right">
                  <span className={`rounded-full px-2 py-1 text-xs font-medium ${
                    activity.status === "verified"
                      ? "bg-valid/10 text-valid"
                      : "bg-tampered/10 text-tampered"
                  }`}>
                    {activity.status === "verified" ? "Verified" : "Flagged"}
                  </span>
                  <p className="mt-1 text-xs text-muted-foreground">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>

      {/* Verification Trend */}
      <GlassCard className="mt-8">
        <h3 className="mb-6 text-lg font-semibold text-foreground">Verification Trend (Last 7 Days)</h3>
        <div className="flex h-48 items-end justify-between gap-2">
          {[
            { day: "Mon", verified: 1820, flagged: 32 },
            { day: "Tue", verified: 1950, flagged: 28 },
            { day: "Wed", verified: 1780, flagged: 45 },
            { day: "Thu", verified: 2100, flagged: 38 },
            { day: "Fri", verified: 2250, flagged: 42 },
            { day: "Sat", verified: 1650, flagged: 25 },
            { day: "Sun", verified: 1430, flagged: 18 },
          ].map((data) => {
            const total = data.verified + data.flagged
            const maxTotal = 2300
            const height = (total / maxTotal) * 100
            const verifiedHeight = (data.verified / total) * 100
            return (
              <div key={data.day} className="flex flex-1 flex-col items-center gap-2">
                <div className="relative w-full overflow-hidden rounded-t-lg bg-tampered/20" style={{ height: `${height}%` }}>
                  <div
                    className="absolute bottom-0 w-full rounded-t-lg bg-gradient-to-t from-primary to-accent"
                    style={{ height: `${verifiedHeight}%` }}
                  />
                </div>
                <span className="text-xs text-muted-foreground">{data.day}</span>
              </div>
            )
          })}
        </div>
        <div className="mt-4 flex items-center justify-center gap-6">
          <div className="flex items-center gap-2">
            <div className="h-3 w-3 rounded-full bg-gradient-to-r from-primary to-accent" />
            <span className="text-sm text-muted-foreground">Verified</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-3 w-3 rounded-full bg-tampered/20" />
            <span className="text-sm text-muted-foreground">Flagged</span>
          </div>
        </div>
      </GlassCard>
    </div>
  )
}
