"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { 
  ShieldCheck, 
  ShieldAlert, 
  Package, 
  Calendar, 
  MapPin, 
  Factory,
  Hash,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  ArrowLeft,
  RotateCcw
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { GlassCard } from "@/components/glass-card"

type VerificationStatus = "valid" | "tampered"

interface ProductData {
  name: string
  origin: string
  manufacturer: string
  productionDate: string
  expiryDate: string
  batchNumber: string
}

interface HashData {
  expected: string
  actual: string
}

// Demo data
const validProduct: ProductData = {
  name: "Organic Valley Milk",
  origin: "Wisconsin, USA",
  manufacturer: "Organic Valley Co.",
  productionDate: "2026-03-10",
  expiryDate: "2026-04-10",
  batchNumber: "OV-2026-0310-A7"
}

const tamperedProduct: ProductData = {
  name: "Premium Coffee Beans",
  origin: "Colombia",
  manufacturer: "Mountain Roast Ltd.",
  productionDate: "2026-02-28",
  expiryDate: "2027-02-28",
  batchNumber: "MR-2026-0228-C3"
}

const hashData: HashData = {
  expected: "a3f8c2e91b4d7f6a0e5c8b3d2f1a9e7c4b6d8f0a2c4e6b8d0f2a4c6e8b0d2f4a",
  actual: "7d2e9f4a1c8b3e6d0f5a2c7b4e9d1f8a3c6b0e2d5f8a1c4b7e0d3f6a9c2b5e8d"
}

export default function VerifyPage() {
  const [status, setStatus] = useState<VerificationStatus>("valid")
  const [isAnimating, setIsAnimating] = useState(true)
  const [showContent, setShowContent] = useState(false)

  useEffect(() => {
    // Initial animation sequence
    const timer = setTimeout(() => {
      setIsAnimating(false)
      setShowContent(true)
    }, 1500)
    return () => clearTimeout(timer)
  }, [status])

  const toggleStatus = () => {
    setIsAnimating(true)
    setShowContent(false)
    setTimeout(() => {
      setStatus(status === "valid" ? "tampered" : "valid")
    }, 300)
  }

  const product = status === "valid" ? validProduct : tamperedProduct

  return (
    <div className="container mx-auto min-h-[calc(100vh-4rem)] px-4 py-8">
      {/* Background glow effects based on status */}
      <div className="fixed inset-0 -z-5 overflow-hidden pointer-events-none">
        {status === "valid" ? (
          <>
            <div className="absolute top-1/4 left-1/2 -translate-x-1/2 h-[600px] w-[600px] rounded-full bg-valid/20 blur-[150px] animate-pulse" />
            <div className="absolute top-1/3 left-1/3 h-[300px] w-[300px] rounded-full bg-valid/15 blur-[100px]" />
          </>
        ) : (
          <>
            <div className="absolute top-1/4 left-1/2 -translate-x-1/2 h-[600px] w-[600px] rounded-full bg-tampered/20 blur-[150px] animate-pulse" />
            <div className="absolute top-1/3 right-1/3 h-[300px] w-[300px] rounded-full bg-tampered/15 blur-[100px]" />
          </>
        )}
      </div>

      {/* Header */}
      <div className="mb-8 flex items-center justify-between">
        <Button variant="ghost" asChild className="gap-2 text-muted-foreground hover:text-foreground">
          <Link href="/scan">
            <ArrowLeft className="h-4 w-4" />
            Back to Scan
          </Link>
        </Button>
        <Button 
          variant="outline" 
          onClick={toggleStatus}
          className="gap-2 border-border bg-card/60 backdrop-blur-xl hover:bg-card/80"
        >
          <RotateCcw className="h-4 w-4" />
          Toggle Demo State
        </Button>
      </div>

      {/* Main Content */}
      <div className="mx-auto max-w-3xl">
        
        {/* Verification Animation */}
        {isAnimating && (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="relative">
              <div className={`h-24 w-24 rounded-full ${status === "valid" ? "bg-valid/20" : "bg-tampered/20"} animate-ping`} />
              <div className={`absolute inset-0 flex items-center justify-center h-24 w-24 rounded-full ${status === "valid" ? "bg-valid/30" : "bg-tampered/30"} backdrop-blur-sm`}>
                {status === "valid" ? (
                  <ShieldCheck className="h-12 w-12 text-valid" />
                ) : (
                  <ShieldAlert className="h-12 w-12 text-tampered" />
                )}
              </div>
            </div>
            <p className="mt-6 text-lg text-muted-foreground animate-pulse">Verifying product integrity...</p>
          </div>
        )}

        {/* Valid State */}
        {showContent && status === "valid" && (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
            
            {/* Main Status Card */}
            <div className="relative">
              {/* Outer glow ring */}
              <div className="absolute -inset-1 rounded-3xl bg-gradient-to-r from-valid/50 via-valid/30 to-valid/50 blur-xl opacity-75" />
              <div className="absolute -inset-0.5 rounded-3xl bg-gradient-to-r from-valid/40 to-valid/60 opacity-50" />
              
              <GlassCard glow="valid" className="relative overflow-hidden rounded-3xl border-valid/40 p-8">
                {/* Inner gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-br from-valid/10 via-transparent to-valid/5" />
                
                <div className="relative text-center">
                  {/* Animated checkmark */}
                  <div className="relative mx-auto mb-6 h-28 w-28">
                    <div className="absolute inset-0 rounded-full bg-valid/20 animate-ping" style={{ animationDuration: "2s" }} />
                    <div className="absolute inset-2 rounded-full bg-valid/30 animate-pulse" />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="flex h-24 w-24 items-center justify-center rounded-full bg-gradient-to-br from-valid to-valid/80 shadow-2xl shadow-valid/50">
                        <ShieldCheck className="h-12 w-12 text-valid-foreground" />
                      </div>
                    </div>
                  </div>
                  
                  <h1 className="mb-3 text-4xl font-bold text-valid drop-shadow-lg">
                    Product is Authentic
                  </h1>
                  <p className="text-lg text-muted-foreground">
                    This product has passed all verification checks and is confirmed genuine.
                  </p>
                  
                  {/* Trust indicators */}
                  <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-valid/20 px-4 py-1.5 text-sm font-medium text-valid">
                      <CheckCircle2 className="h-4 w-4" />
                      Hash Verified
                    </span>
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-valid/20 px-4 py-1.5 text-sm font-medium text-valid">
                      <CheckCircle2 className="h-4 w-4" />
                      Chain Intact
                    </span>
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-valid/20 px-4 py-1.5 text-sm font-medium text-valid">
                      <CheckCircle2 className="h-4 w-4" />
                      Origin Confirmed
                    </span>
                  </div>
                </div>
              </GlassCard>
            </div>

            {/* Product Details Card */}
            <GlassCard className="border-valid/20">
              <h2 className="mb-4 flex items-center gap-2 text-xl font-semibold text-foreground">
                <Package className="h-5 w-5 text-valid" />
                Product Details
              </h2>
              
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="flex items-start gap-3 rounded-xl bg-secondary/50 p-4">
                  <Package className="mt-0.5 h-5 w-5 text-valid" />
                  <div>
                    <p className="text-sm text-muted-foreground">Product Name</p>
                    <p className="font-medium text-foreground">{product.name}</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3 rounded-xl bg-secondary/50 p-4">
                  <MapPin className="mt-0.5 h-5 w-5 text-valid" />
                  <div>
                    <p className="text-sm text-muted-foreground">Origin</p>
                    <p className="font-medium text-foreground">{product.origin}</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3 rounded-xl bg-secondary/50 p-4">
                  <Factory className="mt-0.5 h-5 w-5 text-valid" />
                  <div>
                    <p className="text-sm text-muted-foreground">Manufacturer</p>
                    <p className="font-medium text-foreground">{product.manufacturer}</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3 rounded-xl bg-secondary/50 p-4">
                  <Calendar className="mt-0.5 h-5 w-5 text-valid" />
                  <div>
                    <p className="text-sm text-muted-foreground">Expiry Date</p>
                    <p className="font-medium text-foreground">{product.expiryDate}</p>
                  </div>
                </div>
              </div>

              {/* Hash Display */}
              <div className="mt-4 rounded-xl border border-valid/20 bg-valid/5 p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Hash className="h-4 w-4 text-valid" />
                  <span className="text-sm font-medium text-valid">Verified Hash</span>
                </div>
                <code className="block break-all rounded-lg bg-background/50 p-3 font-mono text-xs text-muted-foreground">
                  {hashData.expected}
                </code>
              </div>
            </GlassCard>
          </div>
        )}

        {/* Tampered State */}
        {showContent && status === "tampered" && (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
            
            {/* Main Status Card */}
            <div className="relative">
              {/* Outer glow ring */}
              <div className="absolute -inset-1 rounded-3xl bg-gradient-to-r from-tampered/50 via-tampered/30 to-tampered/50 blur-xl opacity-75" />
              <div className="absolute -inset-0.5 rounded-3xl bg-gradient-to-r from-tampered/40 to-tampered/60 opacity-50" />
              
              <GlassCard glow="tampered" className="relative overflow-hidden rounded-3xl border-tampered/40 p-8">
                {/* Inner gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-br from-tampered/10 via-transparent to-tampered/5" />
                
                <div className="relative text-center">
                  {/* Animated warning icon */}
                  <div className="relative mx-auto mb-6 h-28 w-28">
                    <div className="absolute inset-0 rounded-full bg-tampered/20 animate-ping" style={{ animationDuration: "1.5s" }} />
                    <div className="absolute inset-2 rounded-full bg-tampered/30 animate-pulse" />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="flex h-24 w-24 items-center justify-center rounded-full bg-gradient-to-br from-tampered to-tampered/80 shadow-2xl shadow-tampered/50">
                        <ShieldAlert className="h-12 w-12 text-tampered-foreground" />
                      </div>
                    </div>
                  </div>
                  
                  <h1 className="mb-3 text-4xl font-bold text-tampered drop-shadow-lg">
                    Product is Tampered
                  </h1>
                  <p className="text-lg text-muted-foreground">
                    Warning: This product failed verification. Supply chain integrity compromised.
                  </p>
                  
                  {/* Warning indicators */}
                  <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-tampered/20 px-4 py-1.5 text-sm font-medium text-tampered">
                      <XCircle className="h-4 w-4" />
                      Hash Mismatch
                    </span>
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-tampered/20 px-4 py-1.5 text-sm font-medium text-tampered">
                      <XCircle className="h-4 w-4" />
                      Chain Broken
                    </span>
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-tampered/20 px-4 py-1.5 text-sm font-medium text-tampered">
                      <AlertTriangle className="h-4 w-4" />
                      Do Not Consume
                    </span>
                  </div>
                </div>
              </GlassCard>
            </div>

            {/* Warning Alert */}
            <GlassCard className="border-tampered/30 bg-tampered/5">
              <div className="flex items-start gap-4">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-tampered/20">
                  <AlertTriangle className="h-6 w-6 text-tampered" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-tampered">Security Warning</h3>
                  <p className="mt-1 text-muted-foreground">
                    The cryptographic hash of this product does not match the expected value. 
                    This indicates potential tampering, counterfeiting, or data corruption in the supply chain.
                    Do not consume this product and report it immediately.
                  </p>
                </div>
              </div>
            </GlassCard>

            {/* Hash Comparison Card */}
            <GlassCard className="border-tampered/20">
              <h2 className="mb-4 flex items-center gap-2 text-xl font-semibold text-foreground">
                <Hash className="h-5 w-5 text-tampered" />
                Hash Mismatch Details
              </h2>
              
              <div className="space-y-4">
                {/* Expected Hash */}
                <div className="rounded-xl border border-valid/30 bg-valid/5 p-4">
                  <div className="mb-2 flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-valid" />
                    <span className="text-sm font-medium text-valid">Expected Hash (Original)</span>
                  </div>
                  <code className="block break-all rounded-lg bg-background/50 p-3 font-mono text-xs text-muted-foreground">
                    {hashData.expected}
                  </code>
                </div>

                {/* Actual Hash */}
                <div className="rounded-xl border border-tampered/30 bg-tampered/5 p-4">
                  <div className="mb-2 flex items-center gap-2">
                    <XCircle className="h-4 w-4 text-tampered" />
                    <span className="text-sm font-medium text-tampered">Actual Hash (Scanned)</span>
                  </div>
                  <code className="block break-all rounded-lg bg-background/50 p-3 font-mono text-xs text-muted-foreground">
                    {hashData.actual}
                  </code>
                </div>

                {/* Visual diff indicator */}
                <div className="flex items-center justify-center gap-2 rounded-xl bg-tampered/10 py-3">
                  <AlertTriangle className="h-5 w-5 text-tampered" />
                  <span className="font-medium text-tampered">100% Hash Difference Detected</span>
                </div>
              </div>
            </GlassCard>

            {/* Product Info (for reference) */}
            <GlassCard className="border-tampered/20 opacity-75">
              <h2 className="mb-4 flex items-center gap-2 text-xl font-semibold text-foreground">
                <Package className="h-5 w-5 text-muted-foreground" />
                Claimed Product Details
                <span className="ml-2 rounded-full bg-tampered/20 px-2 py-0.5 text-xs font-medium text-tampered">Unverified</span>
              </h2>
              
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="flex items-start gap-3 rounded-xl bg-secondary/50 p-4">
                  <Package className="mt-0.5 h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Product Name</p>
                    <p className="font-medium text-foreground">{product.name}</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3 rounded-xl bg-secondary/50 p-4">
                  <MapPin className="mt-0.5 h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Claimed Origin</p>
                    <p className="font-medium text-foreground">{product.origin}</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3 rounded-xl bg-secondary/50 p-4">
                  <Factory className="mt-0.5 h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Claimed Manufacturer</p>
                    <p className="font-medium text-foreground">{product.manufacturer}</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3 rounded-xl bg-secondary/50 p-4">
                  <Calendar className="mt-0.5 h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Claimed Expiry</p>
                    <p className="font-medium text-foreground">{product.expiryDate}</p>
                  </div>
                </div>
              </div>
            </GlassCard>

            {/* Action Buttons */}
            <div className="flex flex-wrap justify-center gap-4">
              <Button 
                variant="destructive" 
                size="lg"
                className="rounded-xl bg-gradient-to-r from-tampered to-tampered/80 shadow-lg shadow-tampered/30 hover:shadow-xl hover:shadow-tampered/40"
              >
                <AlertTriangle className="mr-2 h-5 w-5" />
                Report This Product
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                asChild
                className="rounded-xl border-border bg-card/60 backdrop-blur-xl hover:bg-card/80"
              >
                <Link href="/scan">
                  Scan Another Product
                </Link>
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
