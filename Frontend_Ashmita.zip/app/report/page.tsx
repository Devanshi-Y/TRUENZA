"use client"

import { useState } from "react"
import { GlassCard } from "@/components/glass-card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { AlertTriangle, Send, CheckCircle2, FileWarning } from "lucide-react"

export default function ReportPage() {
  const [productId, setProductId] = useState("")
  const [description, setDescription] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [reportId, setReportId] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!productId.trim() || !description.trim()) return

    setIsSubmitting(true)
    
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))
    
    // Generate report ID
    const id = `RPT-${Date.now().toString(36).toUpperCase()}`
    setReportId(id)
    setIsSubmitting(false)
    setIsSubmitted(true)
  }

  const handleNewReport = () => {
    setProductId("")
    setDescription("")
    setIsSubmitted(false)
    setReportId("")
  }

  return (
    <div className="container mx-auto max-w-2xl px-4 py-12">
      {/* Background glow */}
      <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 h-[400px] w-[400px] rounded-full bg-primary/20 blur-[120px]" />
      </div>

      {/* Header */}
      <div className="mb-8 text-center">
        <div className="mb-4 inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 shadow-lg shadow-amber-500/30">
          <FileWarning className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-3xl font-bold text-foreground">Report Product</h1>
        <p className="mt-2 text-muted-foreground">
          Report suspicious or counterfeit products
        </p>
      </div>

      {!isSubmitted ? (
        <GlassCard>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Product ID */}
            <div className="space-y-2">
              <label htmlFor="productId" className="text-sm font-medium text-foreground">
                Product ID or Hash
              </label>
              <Input
                id="productId"
                value={productId}
                onChange={(e) => setProductId(e.target.value)}
                placeholder="Enter product ID or hash"
                className="h-12 rounded-xl border-border bg-secondary/50 px-4 text-foreground placeholder:text-muted-foreground focus:border-primary focus:ring-primary"
                required
              />
            </div>

            {/* Description */}
            <div className="space-y-2">
              <label htmlFor="description" className="text-sm font-medium text-foreground">
                Description
              </label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe the issue with this product..."
                rows={5}
                className="rounded-xl border-border bg-secondary/50 px-4 py-3 text-foreground placeholder:text-muted-foreground focus:border-primary focus:ring-primary resize-none"
                required
              />
              <p className="text-xs text-muted-foreground">
                Please provide details about why you believe this product is suspicious.
              </p>
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={isSubmitting || !productId.trim() || !description.trim()}
              className="w-full h-12 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 text-white font-semibold shadow-lg shadow-amber-500/30 hover:shadow-xl hover:shadow-amber-500/40 hover:scale-[1.02] transition-all disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
            >
              {isSubmitting ? (
                <span className="flex items-center gap-2">
                  <svg className="h-5 w-5 animate-spin" viewBox="0 0 24 24" fill="none">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  Submitting...
                </span>
              ) : (
                <span className="flex items-center gap-2">
                  <Send className="h-5 w-5" />
                  Submit Report
                </span>
              )}
            </Button>
          </form>
        </GlassCard>
      ) : (
        /* Success State */
        <GlassCard className="text-center relative overflow-hidden">
          {/* Success glow */}
          <div className="absolute inset-0 bg-gradient-to-br from-valid/10 to-transparent" />
          
          <div className="relative space-y-6">
            {/* Success Icon */}
            <div className="inline-flex h-20 w-20 items-center justify-center rounded-full bg-valid/20 shadow-lg shadow-valid/30">
              <CheckCircle2 className="h-10 w-10 text-valid" />
            </div>

            {/* Success Message */}
            <div>
              <h2 className="text-2xl font-bold text-valid mb-2">Report Submitted</h2>
              <p className="text-muted-foreground">
                Thank you for helping us maintain supply chain integrity.
              </p>
            </div>

            {/* Report ID */}
            <div className="rounded-xl border border-border bg-secondary/50 p-4">
              <p className="text-xs text-muted-foreground mb-1">Report Reference ID</p>
              <p className="text-lg font-mono font-semibold text-foreground">{reportId}</p>
            </div>

            {/* Summary */}
            <div className="rounded-xl border border-border bg-secondary/30 p-4 text-left space-y-2">
              <div>
                <p className="text-xs text-muted-foreground">Product ID</p>
                <p className="text-sm font-medium text-foreground">{productId}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Description</p>
                <p className="text-sm text-foreground line-clamp-2">{description}</p>
              </div>
            </div>

            {/* New Report Button */}
            <Button
              onClick={handleNewReport}
              variant="outline"
              className="rounded-xl border-border bg-card/60 hover:bg-card/80 hover:border-primary/50 transition-all"
            >
              <AlertTriangle className="mr-2 h-4 w-4" />
              Submit Another Report
            </Button>
          </div>
        </GlassCard>
      )}
    </div>
  )
}
